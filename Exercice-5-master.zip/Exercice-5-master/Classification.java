
/* 3 */
class Personne{
        /* méthode sommeSalaire: calcul la somme des salaires des personnes présent dans un tableau */
    	public static int sommeSalaire(Personne[] tab){
          int somme = 0;
          for (int i = 0;i<tab.length ;i++ ) {
       	    somme += tab[i].salaire;
          }

          return somme;
	  }


}
