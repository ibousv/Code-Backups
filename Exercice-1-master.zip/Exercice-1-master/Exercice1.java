

class Test {

 public static void echange(int i, int j) {//la méthode prend deux entier en paramétre
   int aux = i;
  i = j;
  j = aux;
 }
 
  public static void main(String[] args) {
     int a = 1;
     int b = 2;
     echange(a,b);
     System.out.println("a = " + a);//a=1
     System.out.println("b = " + b);//b=2
  }
}
