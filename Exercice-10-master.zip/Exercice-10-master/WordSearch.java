//
import java.util.*;

 public class WordSearch{
    /* méthode qui permet de rechercher un mot suivant un texte saisit */ 
  public static void FindWord(String text,String word){// deux paramètres de type String
     String temp="";
     int numero=1;
    for (int i = 0; i < text.length(); i++) {
        if (text.charAt(i)!=' ') {
            temp+=text.charAt(i);
             if (temp.equalsIgnoreCase(word)) {
                System.out.println("Le mot "+word+" apparaît à la place no."+numero);
                break;
             }
        }else{
            temp = "";
            numero++;
        }

       
    }
  }

    public static void main(String[] args) {
        Scanner ib = new Scanner(System.in);
        System.out.println("Saisir le texte:");
        String texte = ib.nextLine();
        System.out.println("Saisir le mot :");
        String mot = ib.nextLine();
        FindWord(texte,mot);

    }
   

}