import java.util.*;

class FullOccurenceCount{
  

    public static void main(String[] args){
        int[] tableau;
        int t=0;
       
        Scanner ib = new Scanner(System.in);
        System.out.println("Saisir la taille du tableau:");
        int taille = ib.nextInt();
        tableau = new int[taille];

         System.out.print("Le tableau est : ");
          // Remplissage aléatoire du tableau 
        for (int i = 0; i < tableau.length; i++) {
            tableau[i] = (int)(Math.random()*20-10);
            System.out.print(tableau[i]+" ");
        }
        System.out.print("\n");
          // Calcul de la taille des tableaux
       int i = 0;
       while(i<tableau.length ) {
           for (int j=i+1;j<tableau.length ;j++ ) {
               if (i==0) {
                   t++;
                   
                   break;
               }else if (tableau[i] == tableau[j] && tableau[i] != tableau[i-1])  {
                   t++;
                   break;
               }else if ( j == (tableau.length-1)) {
                   for (int k= 0;k<i ;k++ ) {
                       if (tableau[i]==tableau[k]) {
                           break;
                       }else if(k==(i-1)) {
                           t++;
                           break;
                       }
                   }
               }
            }

            if ( i == (tableau.length-1)) {
                for (int k= 0;k<i ;k++ ) {
                    if (tableau[i]==tableau[k]) {
                        break;
                    }else if(k==(i-1)) {
                        t++;
                        break;
                    }
                }
            }
           
           i++;
       }
        // Création des deux tableaux (valeurs distinctes et occurrences)
       int[] valeurDistinct= new int[t];
       int[] Occurrence= new int [t];

          i = 0;
        while (i < t) {
           for (int m = 0; m < tableau.length; m++) {
             for (int n=m+1;n<tableau.length ;n++ ) {
                if (m==0) {
                    valeurDistinct[i] = tableau[m];
                    i++;
                    break;
                }else if (tableau[m] == tableau[n] && tableau[m] != tableau[m-1])  {
                    valeurDistinct[i] = tableau[m];
                    i++;
                    break;
                }else if ( n == (tableau.length-1)) {
                    for (int k= 0;k<m ;k++ ) {
                        if (tableau[m]==tableau[k]) {
                            break;
                        }else if(k==(m-1)) {
                            valeurDistinct[i] = tableau[m];
                            i++;
                            break;
                        }
                    }
                }
             }

             if ( m == (tableau.length-1)) {
                for (int k= 0;k<i ;k++ ) {
                    if (tableau[i]==tableau[k]) {
                        break;
                    }else if(k==(i-1)) {
                        valeurDistinct[i] = tableau[m];
                        i++;
                        break;
                    }
                }
              }
            }

          
        }
         // Affichage du premier tableau
        System.out.print("Le tableau des valeurs distincts est : ");
       for (int j : valeurDistinct) {
          System.out.print(j+" ");
       }
        System.out.print("\n");

       for (int j = 0; j < valeurDistinct.length; j++) {
           t = 0;
             for (int j2 = 0; j2 < tableau.length; j2++) {
                if (valeurDistinct[j] == tableau[j2]) {
                    t++;
                }
             }
             Occurrence[j] = t;
       }
         // Affichage du second tableau
       System.out.print("Le tableau des occurrence est : ");
       for (int j : Occurrence) {
        System.out.print(j+" ");
       }
       System.out.print("\n");
    }
  
}