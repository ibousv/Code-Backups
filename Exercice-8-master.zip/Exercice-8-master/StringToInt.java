 import java.util.*;
 public class StringToInt{
      // méthode de conversition d'une chaîne en entier
    public static void StringToInt(String s){
    	String c = "";
         for (int i = 0;i< s.length() ;i++ ) {
         	c+= Character.getNumericValue(s.charAt(i));
         }

         System.out.println(c);// Affichage de la chaîne
    }
      // méthode de vérification de la chaîne
    public static void verification(String s){
    	int cpt = 0;
        
        for (int i = 0;i < s.length() ;i++ ) {
        	if (Character.isDigit(s.charAt(i))) {
        		cpt++;
        	}
        }
    	if (cpt == s.length()) {
    		System.out.println("Votre chaîne correspond à un entier.");
    		StringToInt(s);
    	}
    	else{
    		System.out.println("Votre chaîne de caractères ne correspond pas à un entier!");
    		System.exit(0);
    	}
    }

      public static void main(String[] args) {
      	Scanner ib = new Scanner(System.in);
      	System.out.println("Veuillez saisir un entier :");
      	 String chaine = ib.nextLine();
          verification(chaine);
      }
 }