
public class Compte{

	private int numero;
	private char typeCompte;
	private double solde;
	private int codeSecret;

    // Constructeurs

    public Compte(){
      numero = 999999;
      typeCompte = ' ';
      solde = 0;
      codeSecret = 0;
    }

    public Compte(int unNumero,char unType,double unCode){
        numero = unNumero;
     /*   if (unType == 'D') {
        	typeCompte = unType;
        }
        else if (unType == 'E') {
        	typeCompte = unType;
        }
        else{
        	typeCompte = ' ';
        }
   */
	    if((unType=='D' || unType=='d') && (unType=='E' || unType=='e')){
		    typeCompte = ' ';
	    }
        setCodeSecret();
    }
    
    /* Setteurs */

    public void setCodeSecret(){
    	codeSecret = (int)(Math.random()*(9999-100)+100);//9999+100
    }

    public void setNumero(int unNumero){
       numero = unNumero;
    }

    public void setType(char unType){
    	typeCompte = unType;
    }

    public void setSolde(int unSolde){
	    solde = unSolde;
    }
	
    /* Getteurs */

    public int getNumero(){
    	return numero;
    }

    public int getcodeSecret(){
    	return codeSecret;
    }

    public void getSolde(){
	    return solde;
    }

}
