import java.util.*;
import java.sql.Date;
public class Operation{
   private Date date;
   private double montant;
   static int nbreOperation = 0;
   static int i = 0;
   static Scanner ib = new Scanner(System.in);
   // Constructeurs
   public Operation(Date uneDate,double unMontant){
      date = uneDate;
      montant = unMontant;
      nbreOperation++;
   }

   public Operation(double unMontant){
      date = new Date();
      montant = unMontant;
      nbreOperation++;
   }
   
   // Getteurs
    public Date getDate(){
      return date;
    }

    public double getMontant(){
      return montant;
    }
     // méthode pour la création du tableau
    public static Operation[] creationTableau(){
      Operation[] tableau = new Operation[50]; 
      return tableau;
    }
    static Operation[] tab = creationTableau();

    public static void programme(){
    
       menu();

    }
      // méthode menu comportant le menu à afficher
    public static void menu(){
      
      int choix=0 ;
     
      do{
          System.out.println(" 0. Quitter ");
          System.out.println(" 1. Voir les opérations ");
          System.out.println(" 2. Ajouter une opération ");
          System.out.print("Entrez votre choix : ");
          choix = ib.nextInt();
          switch(choix){
          case 1:
            option1();
            break;
          case 2:
            option2();
          }
      }while(choix != 0);
      
    }
      
      public String toString(){
        
         return "Opération effectué avec succés"+"\n"+
                 "--> Date: "+tab[i].getDate()+"\n"+
                 "--> Montant: "+tab[i].getMontant();
      }
       // Option 1 du menu
      public static void option1(){
         for (Operation i : tab ) {
            
            if (i == null) {
               break;
            }
            else{
               System.out.println("La date :"+i.getDate()+"\n"+
                  "Le montant:"+i.getMontant());
             
            }
            
         }
      }

        // Option 2 du menu
      public static void option2(){
         
         double m;
         //java.util.Date d ou java.sql.Date d = new Date(éventuellement quelques arguments);
         //System.out.println("Comment voulez vous créer l'opération ?");
         System.out.println("Veuillez saisir le montant:");
       
          m = ib.nextInt();
          // System.out.println("Veuillez saisir la date:");
          
          if(nbreOperation<tab.length){
            tab[i] = new Operation(m);
            System.out.println(tab[i]);
             i = nbreOperation;
          }
          else{
           System.out.println("Désolé vous ne pouvez plus ajouter d'opération.");
          }
          
      }
        // méthode main pour les tests
      public static void main(String[] args) {
         
         programme();
      }

}
