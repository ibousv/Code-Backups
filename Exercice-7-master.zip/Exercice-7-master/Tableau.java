// importation du package util
import java.util.*;

public class Tableau{
 // méthode pour la création du tableau
 public static int[] creationTableau(){
    int tableau[] = new int[5];
    Scanner ib = new Scanner(System.in);
    for (int i = 0;i<tableau.length;i++) {
        System.out.print("Veuillez saisir le montant: ");
        tableau[i] = ib.nextInt();
        System.out.print("\n");
    }

    return tableau;
 }

 // méthode pour l'affichage du tableau avant tri
 public static void affichageTableau(int[] tab){
     System.out.print("Le tableau est: ");
    for (int i :tab ) {// foreach loop
         System.out.print(i+" ");
    }
     System.out.print("\n");
 }

 // méthode pour trier le tableau
 public static void triTableau(int[] tab){
    Arrays.sort(tab);
 }

 // méthode pour l'affichage du tableau après tri
 public static void affichageApresTri(int[] tab){

    Arrays.toString(tab);
 } 


}