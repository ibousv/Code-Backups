
class Personne {
 String prenom;
 String nom;
 private int age;
 static int nbPersonnes = 0;

 public Personne(String p, String n, int a){//constructeur
   prenom = p;
   nom = n;
   age = a;
   nbPersonnes++;
 }

  public void affichePersonne1(){// ajout de \n pour l'affichage
    System.out.println(prenom+"\n"+nom+"\n"+age);
  }
    
}
 
public class ProgPrincipal{
    /* méthode anniversaire : ajoute 1 à l'age  */
    public static void anniversaire(Personne p){
      p.age +=1;
    }

    public static void main(String[] args){
      Personne p1 = new Personne("Jean", "Durand", 25);
       System.out.println(p1.prenom);
       System.out.println(p1.nom);
       System.out.println(p1.age);
      
    }
}
