

public class Exercice2{

   /***1***/

   public static int[] creerTableau(int n){//méthode pour créer un tableau
      int Tableau[]= new int[n];
      int i;
      for(i=0;i<n;i++){
       Tableau[i] = i+1;
      }
      
      return Tableau;
   }
   
   /***2***/

   public static int somme(int[] tab){//méthode pour calculer la somme des éléments d'un tableau
     int somme=0,i;
     
      for(i=0;i<tab.length;i++){
       somme += tab[i];
      }
      
      return somme;
   }
   
   /***3***/

   public static void incremente(int[] tab){//méthode pour incrémenter toutes les valeurs du tableau par 1
       for(int i=0;i<tab.length;i++){
       tab[i] += 1;
      }
   }

}