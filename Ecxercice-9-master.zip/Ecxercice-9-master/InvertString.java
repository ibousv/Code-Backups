import java.util.*;

public class InvertString{

    /* méthode reverse */
     // Utilisation de la méthode append() et reverse() présent dans la class StringBuilder
   public static void reverse(StringBuilder s,String c){
       s.append(c);// append nous permet de mettre la chaîne c dans s
       s.reverse();// reverse nous permet d'inverser s soit une chaîne 
      System.out.println("L 'inversion de la chaîne donne :"+s);
   }
   /* 2e méthode reverse alternative du premier ne prenant qu'un paramètre de type String */
    //  Boucle sur la chaîne en question en partant sur le dernier index 
   public static void reverse(String c){
   	  String s="";
   	  for (int i = (c.length()-1);i>=0 ;i-- ) {
   	  	  s += c.charAt(i);
   	  }
   	  System.out.println("L 'inversion de la chaîne donne :"+s);
   }
   
	public static void main(String[] args) {
		Scanner ib = new Scanner(System.in);
		System.out.println("Entrez une chaîne de caractères :");
		String chaine = ib.nextLine();
        StringBuilder s = new StringBuilder();
        reverse(s,chaine);

	}
}