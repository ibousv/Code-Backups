

public class HelloWorld{
   // méthode de l'objet o1
   public  void mO1(){
       mO2();
   }
   // méthode de l'objet o2
   public void mO2(){
    System.out.println("Hello World.");
   }
   
  public static void main(String[] args){
    HelloWorld o1 = new HelloWorld();
     HelloWorld o2 = new HelloWorld();
     o1.mO1();
  }
}

